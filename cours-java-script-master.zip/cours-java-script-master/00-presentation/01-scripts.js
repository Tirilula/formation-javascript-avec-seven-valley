// lire une balise
let balise = document.getElementById("demo").innerHTML;
console.log(balise);
//alert(balise);